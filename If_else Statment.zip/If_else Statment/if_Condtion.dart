void main(){

  /**
   * if ( condation  == true )
   * // code
   */
  var degree;
  degree =521;
  if ( degree>=100 || degree <0)
  {
    print (" try agne !! ");
  }
  else if (degree >=85)
  {
    print (" EXELLANT !! ");
  }
  else if (degree >=75  )
  {
    print (" VERY GOOD !! ");
  }
  else  if (degree >=65  )
  {
    print (" GOOD !! ");
  }
  else  if (degree >=50  )
  {
    print ("BASS !! ");
  }
  else
  {
    print ("FELL !! ");
  }


}