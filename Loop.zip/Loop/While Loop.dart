void main (){


  int year =2004,c=0 ;
  while(year<2030){
    print("$c :$year");
    if (year==2027)
       break;
    if(year== 2022) {
      year++;
      c++;
      continue;

    }
    year++;
    c++;
  }
}