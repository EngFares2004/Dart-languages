void main(){
  int a= 22;
  do{
     print(a);

     a++;
  }while(a<22);




}