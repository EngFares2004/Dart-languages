void main (){
String d ="";
  for (var i = 1 ; i <=  10; i ++ ){

     for (var j =1; j <= (10-i) ; j++){
      d+=" ";

     }
     for (var j =1; j <= (2*i-1) ; j++){
     d+="*";

     }
     d+="\n";
  }
print(d);

}