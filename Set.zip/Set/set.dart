
void main () {
  //list
Set  list_item = {
    "fares","mohammed ","Ahmed"
    ,1 ,2, 3 ,
    [70,70,70],[70,70,70],[79,80,95]};


//add
  list_item.add(true);
  list_item.add(['a','b','c']);
//add All
  list_item.addAll(['s',"ss","sss"]);

//length
  print("number of item in list :${list_item.length}");

  //checked
  print("checked item in list :${list_item.isNotEmpty}");

//print
  print(list_item);
  print("===========print list using foreach============");
  list_item.forEach((element) {
    print(element);
  });
  print("===========print list using  while============");


  //remove
  list_item.remove("w");

  print(list_item);
}