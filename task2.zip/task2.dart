import 'dart:io';
void main(List<String> arguments){
  int count_item =0;
  //todo number item of list
  print("Enter number of element: ");
  String y =stdin.readLineSync()!;
    count_item =int.parse(y);

  List<String> list =[];
  print("Enter element of list : ");
//todo added items of list
  for(int i=1 ;i<= count_item ; i++){
    String y =stdin.readLineSync()!;
    list.add(y);
  }
 int count =0;
  //todo print item start Capital letter
  print("item start Capital letter");
  list.forEach(
          (element) {
            if (element[0] ==element[0].toLowerCase())
              count_item++;
            else
             print(element);

  });
print("number of element of start small letter :$count_item");
}