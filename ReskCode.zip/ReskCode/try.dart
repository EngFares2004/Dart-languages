import 'dart:async';
import 'dart:io';

void main(){


  int a=0,b=19,res;
  try{
    res =b ~/a;

    print(res);
  }catch(e){
    if(e is FormatException)
      print("FormatException");
    else if(e is SocketException)
      print("SocketException");
    else if(e is RandomAccessFile)
      print("RandomAccessFile");
    else if(e is HandleUncaughtErrorHandler)
      print("Unhandled exception");
    else
    print ("Error");
  }

}