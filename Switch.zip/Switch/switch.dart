import 'dart:io';

void main (List<String> arguments){
  int  price = 1000;
  String y =stdin.readLineSync()!;
  price =int.parse(y);
  switch(price) {
    case 1000:
      {
        print("I have 1000 dollar ");
      }
      break;
    case 2000:
      {
        print("I have 2000 dollar ");
      }
      break;
    default:
      print("I do not no having money!!   ");



  }
 
}